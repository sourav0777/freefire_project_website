import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import { OpenAI } from 'openai';
import Message from './models/Message.js'; // ✅ Include `.js` in import

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// ✅ Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('❌ MongoDB Error:', err));

// ✅ Initialize OpenAI via OpenRouter
const openai = new OpenAI({
  baseURL: 'https://openrouter.ai/api/v1',
  apiKey: process.env.OPENROUTER_API_KEY,
});

// ✅ Handle chat messages
app.post('/chat', async (req, res) => {
  const userMessage = req.body.message;
  console.log("📩 Received from user:", userMessage);

  try {
    const gptRes = await openai.chat.completions.create({
      model: "moonshotai/kimi-k2:free", // ✅ Using your selected model
      messages: [{ role: "user", content: userMessage }],
    });

    const botReply = gptRes.choices[0].message.content;
    console.log("✅ GPT Reply:", botReply);

    // ✅ Save to MongoDB
    const chat = new Message({ userMessage, botReply });
    await chat.save();

    res.json({ reply: botReply });

  } catch (error) {
    console.error("❌ OpenAI Error:", error.message);
    res.status(500).json({ error: "Failed to talk to GPT" });
  }
});

app.listen(5000, () => {
  console.log('🚀 Server is running on http://localhost:5000');
});
