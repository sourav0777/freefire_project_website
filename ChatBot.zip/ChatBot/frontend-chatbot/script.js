document.getElementById("chat-form").addEventListener("submit", async function (e) {
  e.preventDefault();
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (!message) return;

  const userDiv = document.createElement("div");
  userDiv.className = "chat-bubble user";
  userDiv.textContent = message;
  document.getElementById("chat-box").appendChild(userDiv);

  document.getElementById("chat-box").scrollTop = document.getElementById("chat-box").scrollHeight;

  input.value = "";

  try {
    const res = await fetch("http://localhost:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });

    const data = await res.json();
    const botDiv = document.createElement("div");
    botDiv.className = "chat-bubble bot";
    botDiv.textContent = data.reply || "Bot did not respond.";
    document.getElementById("chat-box").appendChild(botDiv);

    document.getElementById("chat-box").scrollTop = document.getElementById("chat-box").scrollHeight;

  } catch (err) {
    const botDiv = document.createElement("div");
    botDiv.className = "chat-bubble bot";
    botDiv.textContent = "❌ Server error.";
    document.getElementById("chat-box").appendChild(botDiv);


    document.getElementById("chat-box").scrollTop = document.getElementById("chat-box").scrollHeight;
  }
});

// Theme Switcher
const themeButtons = document.querySelectorAll(".theme-btn");
const body = document.body;
const savedTheme = localStorage.getItem("chat-theme") || "light";
applyTheme(savedTheme);

themeButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    themeButtons.forEach((b) => b.classList.remove("selected"));
    btn.classList.add("selected");

    const selected = btn.textContent.trim().toLowerCase();
    applyTheme(selected);
    localStorage.setItem("chat-theme", selected);
  });
});

function applyTheme(theme) {
  if (theme === "dark") {
    body.classList.add("dark");
  } else {
    body.classList.remove("dark");
  }
}
